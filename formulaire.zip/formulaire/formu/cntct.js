function estAlphabetique() {
  let x = document.getElementById("chaine").value;
  let y = x.toUpperCase();
  let i = 0;
  while (i < y.length && y.charCodeAt(i) >= 65 && y.charCodeAt(i) <= 90) {
    i++;
  }
  if (i != y.length) {
    text = "this is not invalid name";
  } else {
    text = "correct name";
  }
  document.getElementById("err1").innerHTML = text;
}

function estAlphabetiqu() {
  let x = document.getElementById("chain").value;
  let y = x.toUpperCase();
  let i = 0;
  while (i < y.length && y.charCodeAt(i) >= 65 && y.charCodeAt(i) <= 90) {
    i++;
  }
  if (i != y.length) {
    text = "this is not invalid name";
  } else {
    text = "correct name";
  }
  document.getElementById("err2").innerHTML = text;
}

function validateEmail() {
  let email = document.getElementById("ghy").value;
  // Check if the email contains "@" and "."
  if (email.indexOf("@") !== -1 && email.indexOf(".") !== -1) {
    // Extract the domain part after "@" and check if it contains "."
    let domain = email.slice(email.indexOf("@") + 1);
    if (domain.indexOf(".") !== -1) {
      text = "this is correct email";
    }
    document.getElementById("err3").innerHTML = text;
  } else {
    text = "incorrect email";
  }
  document.getElementById("err3").innerHTML = text;
}

function estNumerique() {
  let x = document.getElementById("nummm").value;
  for (let i = 0; i < x.length; i++) {
    const codeAscii = x.charCodeAt(i);
    if (codeAscii < 48 || codeAscii > 57) {
      text = "this is incorrect number";
    } else {
      text = "this is correct number";
    }
    document.getElementById("err4").innerHTML = text;
  }
}
